import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
# from keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array
from tensorflow.keras.utils import img_to_array, load_img
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential, load_model
from flask import jsonify
import json


img_width, img_height = 150, 150
model_path = './model.h5'
model_weights_path = './weights.h5'
model = load_model(model_path)
model.load_weights(model_weights_path)

def predict(file):
  x = load_img(file, target_size=(img_width,img_height))
  x = img_to_array(x)
  x = np.expand_dims(x, axis=0)
  array = model.predict(x)
  result = array[0]
  # answer = np.argmax(result)
  # print(result)
  if result == 0:
    # print("Kucing Detection")
    # x = {"name": "Kucing Detection"}
    # print(json.dumps(x)) 
    return "Kucing Detection"
  else:
    # x = {"name": "Anjing Detection"}
    # print(json.dumps(x)) 
    return "Anjing Detection"



# def image_detect(image):
#   name = image
#   result = predict(name)
# counter = 1
# while counter<=2:
# name ='test/1.jpg'
  # name = 'test/'+str(counter)+'.jpg'
# result = predict(name)
# counter = counter +1
