# from flask import Flask, request, send_from_directory, Response
# from flask import 
from flask import Flask, jsonify, request, send_from_directory, Response, render_template
from werkzeug.utils import secure_filename
from io import BytesIO
import catANDI
import os
import base64

UPLOAD_FOLDER = 'uploads/'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/upload', methods = ['POST'])
def upload():
	if request.method == 'POST':
		file = request.files['file']
		filename  = secure_filename(file.filename)
		file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
		# name = "test/2.jpg"
		file_up = 'uploads/' + filename

		with open(file_up, "rb") as image_file:
			encoded_string = base64.b64encode(image_file.read())
			imgx = str(encoded_string).replace("b'", "")
			kutip = str(imgx).replace("'", "")

		result = catANDI.predict(file_up)

		return jsonify(hasil=result,img=kutip)




if __name__ == '__main__':
    app.run(host="127.0.0.1", port=8000)